# 🚀 Cashblack — Flutter Upgrade Pipeline

Bu fayllarni sizning `cashblack` repo'ngizga qo'shing.

## 📁 Fayl joylashuvi

```
cashblack/
└── .github/
    └── workflows/
        ├── flutter-upgrade.yml   ← Asosiy upgrade workflow
        └── weekly-check.yml      ← Haftalik tekshiruv
```

## 🔧 Aniqlangan muammolar

| Muammo | Hozirgi | Yangi |
|--------|---------|-------|
| Android Gradle Plugin | `7.3.0` | `8.7.0` |
| Kotlin | `1.9.0` | `2.1.0` |
| Gradle Wrapper | `7.4` | `8.9` |
| compileSdkVersion | `34` | `35` |
| `flutter_countdown_timer` | **Abandoned** ⚠️ | `timer_builder` |

## 🚀 Ishlatish

### 1. Fayllarni repo'ga qo'shing
```bash
# Bu papkadagi .github/ ni cashblack repo'ngizga copy qiling
cp -r .github/ /path/to/cashblack/
```

### 2. GitHub'da workflow'ni ishga tushiring
1. GitHub → cashblack repo → **Actions** tab
2. **"🚀 Flutter Auto-Upgrade"** workflow'ni tanlang
3. **"Run workflow"** tugmasini bosing
4. `create_pr: true` qilib ishga tushiring

### 3. Natija
Workflow quyidagilarni qiladi:
- ✅ Yangi branch yaratadi (`chore/flutter-upgrade-YYYYMMDD`)
- ✅ Barcha muammolarni avtomatik tuzatadi
- ✅ APK build sinab ko'radi
- ✅ PR ochadi
- ✅ GitHub Issue yaratadi (muvaffaqiyatli yoki xatolik bilan)

## ⚠️ Qo'lda qilish kerak bo'lgan narsa

`flutter_countdown_timer` paketini kod ichida ham almashtirish kerak:

```dart
// ESKI (ishlmaydi):
import 'package:flutter_countdown_timer/flutter_countdown_timer.dart';
CountdownTimer(endTime: ..., ...)

// YANGI:
import 'package:timer_builder/timer_builder.dart';
TimerBuilder.periodic(Duration(seconds: 1), builder: (context) { ... })
```

## 📅 Haftalik tekshiruv

`weekly-check.yml` har dushanba kuni avtomatik ishlaydi va
eskirgan paketlar topilsa GitHub Issue ochadi.
